package com.robosoft.lorem.model;

public class Orders
{

}
