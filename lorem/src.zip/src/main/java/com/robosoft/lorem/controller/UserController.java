package com.robosoft.lorem.controller;

import com.robosoft.lorem.model.*;
import com.robosoft.lorem.service.UserService;
import com.robosoft.lorem.service.UserServiceImpl;
import com.robosoft.lorem.utility.JWTUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
public class UserController
{
    @Autowired
    private UserService userService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Autowired
    private JWTUtility jwtUtility;


    @PostMapping("/authenticate")
    public JWTResponse authenticate(@RequestBody JWTRequest jwtRequest) throws Exception
    {

        try
        {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            jwtRequest.getEmailId(),
                            jwtRequest.getPassword()
                    )
            );
        }
        catch (BadCredentialsException e)
        {
            throw new Exception("INVALID_CREDENTIALS", e);
        }

        final UserDetails userDetails = userService.loadUserByUsername(jwtRequest.getEmailId());

        final String token = jwtUtility.generateToken(userDetails);

        return  new JWTResponse(token);
    }

    @PutMapping("/likeBrand")
    public String addToFav(@RequestBody FavTable favTable)
    {
        return userServiceImpl.addToFavourite(favTable);
    }

    @GetMapping("/viewPopularBrands")
    public Map<Integer,List<BrandList>>listPopularBrands()
    {
        return userServiceImpl.viewPopularBrands();
    }

    @GetMapping("/viewAllBrands")
    public Map<Integer,List<BrandList>> viewAllPopularBrands()
    {
        return userServiceImpl.viewAllBrands();
    }

    @PostMapping("/review")
    public String addReview(@ModelAttribute ReviewInfo reviewInfo)
    {
        return userServiceImpl.addReview(reviewInfo);
    }



}
