package com.robosoft.lorem.service;
import com.robosoft.lorem.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import java.io.File;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class UserServiceImpl
{
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    AdminService adminService;

    int lowerLimit = 0;
    int upperLimit = 1;

    public String getUserNameFromToken()
    {
        String username;
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails)
        {
            username = ((UserDetails) principal).getUsername();
        }
        else
        {
            username = principal.toString();
        }
        return username;
    }

    public String addToFavourite(FavTable favTable)
    {
        try
        {
            String email = getUserNameFromToken();
            int id = jdbcTemplate.queryForObject("select userId from user where emailId=?", Integer.class, new Object[]{email});
            jdbcTemplate.update("insert into favTable values(?,?)", id, favTable.getBrandId());
            return "added to favourites";
        }
        catch (Exception e)
        {
            return "Something Went Wrong";
        }
    }

    public Map<Integer, List<BrandList>> viewPopularBrands()
    {
        Map<Integer, List<BrandList>> popular = new HashMap<>();
        try
        {
            int brandNo = jdbcTemplate.queryForObject("select brandId from favTable group by brandId limit ?,?", Integer.class, new Object[]{lowerLimit, upperLimit});
            List<BrandList> brands = jdbcTemplate.query("select brandName, description, logo, profilePic, brandOrigin from brand where brandId=?", new BeanPropertyRowMapper<>(BrandList.class), brandNo);
            lowerLimit = lowerLimit + 1;
            popular.put(upperLimit, brands);
            return popular;
        }
        catch (EmptyResultDataAccessException e)
        {
            lowerLimit = lowerLimit - 1;
            int brandNo = jdbcTemplate.queryForObject("select brandId from favTable group by brandId limit ?,?", Integer.class, new Object[]{lowerLimit, upperLimit});
            List<BrandList> brands = jdbcTemplate.query("select brandName, description, logo, profilePic, brandOrigin from brand where brandId=?", new BeanPropertyRowMapper<>(BrandList.class), brandNo);
            popular.put(brands.size(), brands);
            return popular;
        }
    }

    public Map<Integer, List<BrandList>> viewAllBrands()
    {
        Map<Integer, List<BrandList>> theThings = new HashMap<>();
        List<BrandList> brandLists = jdbcTemplate.query("select brandName, description, logo, profilePic, brandOrigin from brand", new BeanPropertyRowMapper<>(BrandList.class));
        theThings.put(brandLists.size(), brandLists);
        return theThings;
    }

    public String addReview(ReviewInfo reviewInfo)
    {
        try
        {
            String email = getUserNameFromToken();
            int id = jdbcTemplate.queryForObject("select userId from user where emailId=?", Integer.class, new Object[]{email});
            System.out.println(id);
            int userId = jdbcTemplate.queryForObject("select userId from orders where userId=? group by userId", Integer.class, new Object[]{id});
            System.out.println(userId);
            int restaurantId = jdbcTemplate.queryForObject("select restaurantId from orders where userId=? group by restaurantId", Integer.class, new Object[]{userId});
            if (restaurantId == reviewInfo.getRestaurantId())
            {
                String query = "insert into review (userId, restaurantId, description, localDate, foodRating, serviceRating) values(?,?,?,?,?,?)";
                jdbcTemplate.update(query, reviewInfo.getUserId(), reviewInfo.getRestaurantId(), reviewInfo.getDescription(), LocalDate.now(), reviewInfo.getFoodRating(), reviewInfo.getServiceRating());
                int reviewId = jdbcTemplate.queryForObject("select max(reviewId) from review where userId=?", Integer.class, new Object[]{reviewInfo.getUserId()});
                ReviewInfo reviewInfo1 = jdbcTemplate.queryForObject("select foodRating, serviceRating from review where reviewId=?", new BeanPropertyRowMapper<>(ReviewInfo.class), reviewId);
                jdbcTemplate.update("update review set averageRating=? where reviewId=?", (reviewInfo1.getFoodRating() + reviewInfo1.getServiceRating()) / 2, reviewId);
                try
                {
                    if (reviewInfo.getMultipartFileList()==null)
                    {
                        for (int i = 0; i < reviewInfo.getMultipartFileList().size(); i++)
                        {
                            String fileName = reviewInfo.getMultipartFileList().get(i).getOriginalFilename();
                            fileName = UUID.randomUUID().toString().concat(adminService.getExtension(fileName));
                            File file = adminService.convertToFile(reviewInfo.getMultipartFileList().get(i), fileName);
                            String TEMP_URL = adminService.uploadFile(file, fileName);
                            file.delete();
                            jdbcTemplate.update("insert into photo (photoPic, reviewId) values(?,?)", TEMP_URL, reviewId);
                        }
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                    return "Review Added";
                }
            }
            return "Review Added";
        }
        catch (Exception e)
        {
            return "Failed to add review";
        }

        public List<>
    }

}
